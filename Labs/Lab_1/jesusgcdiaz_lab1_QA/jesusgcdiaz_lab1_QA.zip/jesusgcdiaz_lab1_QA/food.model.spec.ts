import { Food } from './food.model';

